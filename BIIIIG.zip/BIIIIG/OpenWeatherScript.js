(function() {
	"use strict";
	
	var main = function() {
        
		var url = 'http://api.openweathermap.org/data/2.5/weather?zip=28804,us&units=imperial&APPID=81899cb18139bf576e0186c07ef81fff' ;
        
        var enterHandler = function(){
            $.get(url, function(TempCall) {
                console.log(TempCall);
            
                var TempResult = (TempCall.main.temp).toFixed(0);
                document.getElementById("see").innerHTML= TempResult;
                
            });
            
            ///////////////////////////////////////////
            
            $.get(url, function(DescCall) {
                console.log(DescCall);
            
                var DescResult = DescCall.weather[0].main;
                
                //var DescResult = "fvevrainfvfkjbvk";
                //var DescResult = "fvevsstormbfvfkjbvk";
                //var DescResult = "fvevlightningbfvfbvk";
                //var DescResult = "fvevthunderfvfkjbvk";
                //var DescResult = "fvevsunfvfkjbvk";
                //var DescResult = "fvevclearfvfkjbvk";
                //var DescResult = "fvevcloudfvfkjbvk";
                //var DescResult = "wgovovercastettgf";
                //var DescResult = "fvevsnowkjbvk";
                
                document.getElementById("desc").innerHTML= DescResult;
                
                var x = DescResult.search(/rain/i);
                var y = DescResult.search(/storm/i);
                if ((x != -1) || (y != -1)) {
                    document.getElementById("pic").innerHTML='<img src="raining2.png">';
                }
                
                x = DescResult.search(/lightning/i);
                y = DescResult.search(/thunder/i);
                if (x != -1 || (y != -1)) {
                    document.getElementById("pic").innerHTML='<img src="lightning2.png">';
                }
                
                x = DescResult.search(/sun/i);
                y = DescResult.search(/clear/i);
                if (x != -1 || (y != -1)) {
                    document.getElementById("pic").innerHTML='<img src="Sun.png">';
                }
                
                x = DescResult.search(/cloud/i);
                y = DescResult.search(/overcast/i);
                if ((x != -1) || (y !=-1)) {
                    document.getElementById("pic").innerHTML='<img src="Clouds.png">';
                }
                
                x = DescResult.search(/snow/i);
                if (x != -1) {
                    document.getElementById("pic").innerHTML='<img src="snowing2.png">';
            }
            });
            
        };
        
        
        var video = document.querySelector("#videoElement");
 
        navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia || navigator.oGetUserMedia;
 
        if (navigator.getUserMedia) {       
            navigator.getUserMedia({video: true}, handleVideo, videoError);
        };
 
        function handleVideo(stream) {
            video.src = window.URL.createObjectURL(stream);
        };
 
        function videoError(e) {
            // do something
        };
        
        
        $('.enter').on("click",  enterHandler);
    };
	
	$(document).ready(main);
}());