(function() {
	"use strict";
	
	var main = function() {
        var ZIP = 28804;
        ZIP = parseInt(window.prompt("Please enter your ZIP code: "));
        
		var url = 'http://api.worldweatheronline.com/premium/v1/weather.ashx?key=6444935f438c465ab6a00134172403&q='+ZIP+'&num_of_days=3&format=JSON&callback=?';
        
        
        var $ZIPDiv = $('<div id="ZIP">');
        document.getElementById("ZIP").innerHTML= "ZIP Code: "+ZIP;
        
        //The following gets the current weather description
        $.getJSON(url, function(WeatherDes) {
            
			console.log(WeatherDes);
            
			var response = WeatherDes.data.current_condition[0].weatherDesc[0].value;
            document.getElementById("desc").innerHTML= "Weather looks like: "+response+".";
            
            var x = response.search(/rain/i);
            var y = response.search(/storm/i);
            if ((x != -1) || (y != -1)) {
                document.getElementById("weatherPic").innerHTML='<img src="Img/Rain.png" style="height:114px">';
                document.getElementById("ObjectText").innerHTML='What you should bring:';
                document.getElementById("ObjectPic").innerHTML='<img src="Img/Umbrella.png" style="height:114px">';
            }
            
            x = response.search(/sun/i);
            if (x != -1) {
                document.getElementById("weatherPic").innerHTML='<img src="Img/Sun.png" style="height:114px">';
                
                document.getElementById("ObjectText").innerHTML='What you should bring:';
                document.getElementById("ObjectPic").innerHTML='<img src="Img/Sunglasses.svg" style="height:114px">';
            }
            x = response.search(/cloud/i);
            if (x != -1) {
                document.getElementById("weatherPic").innerHTML='<img src="Img/Clouds.png" style="height:114px">';
            }
            x = response.search(/clear/i);
            if (x != -1) {
                document.getElementById("weatherPic").innerHTML='<img src="Img/clear.jpg" style="height:114px">';
            }
            x = response.search(/snow/i);
            if (x != -1) {
                document.getElementById("weatherPic").innerHTML='<img src="Img/Snow.png" style="height:114px">';
                
                document.getElementById("ObjectText").innerHTML='What you should bring:';
                document.getElementById("ObjectPic").innerHTML='<img src="Img/SnowObj.png" style="height:114px">';
            }
		});
        
        //The following gets temp and wind info.
		$.getJSON(url, function(BigResponse) {
			console.log(BigResponse);
			var response = BigResponse.data.current_condition[0];
            var count = 0;
            while (count<17){
                for (var prop in response) {
				    var itemVal = response[prop];
                    if (count == 1){
                        document.getElementById("TempinC").innerHTML="Actual Temp. is: "+itemVal+" in Celsius";
                    }
                    if (count == 2){
                        document.getElementById("TempinF").innerHTML="Actual Temp. is: "+itemVal+" in Fahrenheit";
                    }
                    if (count == 6){
                        document.getElementById("WindinM").innerHTML="Wind: "+itemVal+" in Miles per hour";
                    }
                    if (count == 7){
                        document.getElementById("WindinK").innerHTML="Wind: "+itemVal+" in Kilometers per hour";
                    }
                    if (count == 16){
                        document.getElementById("feelsTemp").innerHTML = "Temperature feels like: "+itemVal+"F";
                        if (itemVal >= 70) {
                            document.getElementById("clothes").innerHTML='<img src="Img/Hot.png">';
                        } else if (itemVal >= 50){
                            document.getElementById("clothes").innerHTML='<img src="Img/Avg.png">';
                        } else if (itemVal >= 40){
                            document.getElementById("clothes").innerHTML='<img src="Img/Chilly.png">';
                        } else {
                            document.getElementById("clothes").innerHTML='<img src="Img/Cold.png">';
                        }
                    }
                    count = count+1;
			     }
            }
		});
        
        //the following gets the UV info
        $.getJSON(url, function(UVResponse) {
			console.log(UVResponse);
			var response = UVResponse.data.weather[0].uvIndex;
            document.getElementById("UV").innerHTML= "UV Index is: "+response+"";
            if (response > 8){
                document.getElementById("UVText").innerHTML='What level of sunblock you need:';
                document.getElementById("SPF").innerHTML= 'SPF: 30';
            } else if (response > 6){
                document.getElementById("UVText").innerHTML='What level of sunblock you need:';
                document.getElementById("SPF").innerHTML= 'SPF: 15-30';
            } else if (response > 3){
                document.getElementById("UVText").innerHTML='What level of sunblock you need:';
                document.getElementById("SPF").innerHTML= 'SPF: 15';
            } else {
                document.getElementById("UVText").innerHTML="You don't need sunblock!";
                document.getElementById("SPF").innerHTML= 'No Sunblock';
            }
		});
        
        //the following gets weather info for the day after tomorrow
        $.getJSON(url, function(DatResponse) {
			console.log(DatResponse);
			var response = DatResponse.data.weather[2];
            var count = 0;
            var sum = parseInt(0);
            while (count<6){
                for (var prop in response) {
				    var itemVal = response[prop];
                    if (count == 0){
                        document.getElementById("DATDate").innerHTML="Date: "+itemVal+"";
                    } else if (count == 3){
                        document.getElementById("DAT_MaxF").innerHTML="Max Temp: "+itemVal+"F";
                        itemVal = parseInt(itemVal);
                        sum = sum + itemVal;
                    } else if (count == 5){
                        document.getElementById("DAT_MinF").innerHTML="Min Temp: "+itemVal+"F";
                        itemVal = parseInt(itemVal);
                        sum = sum + itemVal;
                    }
                    count = count+1;
			     }
            }
            document.getElementById("DAT_AvgF").innerHTML="Avg Temp: "+sum/2+"F"; 
            
            if (sum/2 >= 70) {
                document.getElementById("DATPic").innerHTML='<img src="Img/Hot.png">';
            } else if (sum/2 >= 50){
                document.getElementById("DATPic").innerHTML='<img src="Img/Avg.png">';
            } else if (sum/2 >= 40){
                document.getElementById("DATPic").innerHTML='<img src="Img/Chilly.png">';
            } else {
                document.getElementById("DATPic").innerHTML='<img src="Img/Cold.png">';
            }
        });
        
        //the following gets info for tomorrow
        $.getJSON(url, function(TomResponse) {
			console.log(TomResponse);
			var response = TomResponse.data.weather[1];
            var count = 0;
            var sum = parseInt(0);
            while (count<6){
                for (var prop in response) {
				    var itemVal = response[prop];
                    if (count == 0){
                        document.getElementById("TomDate").innerHTML="Date: "+itemVal+"";
                    } else if (count == 3){
                        document.getElementById("Tom_MaxF").innerHTML="Max Temp: "+itemVal+"F";
                        itemVal = parseInt(itemVal);
                        sum = sum + itemVal;
                    } else if (count == 5){
                        document.getElementById("Tom_MinF").innerHTML="Min Temp: "+itemVal+"F";
                        itemVal = parseInt(itemVal);
                        sum = sum + itemVal;
                    }
                    count = count+1;
			     }
            }
            document.getElementById("Tom_AvgF").innerHTML="Avg Temp: "+sum/2+"F"; 
            
            if (sum/2 >= 70) {
                document.getElementById("TomPic").innerHTML='<img src="Img/Hot.png">';
            } else if (sum/2 >= 50){
                document.getElementById("TomPic").innerHTML='<img src="Img/Avg.png">';
            } else if (sum/2 >= 40){
                document.getElementById("TomPic").innerHTML='<img src="Img/Chilly.png">';
            } else {
                document.getElementById("TomPic").innerHTML='<img src="Img/Cold.png">';
            }
        });
        
        //the following gets sunrise info
        $.getJSON(url, function(SunriseResponse) {
			console.log(SunriseResponse);
			var response = SunriseResponse.data.weather[0].astronomy[0].sunrise;
            document.getElementById("RiseTime").innerHTML= "Sun rise: "+response;
		});
        
        //the following gets sunset info
        $.getJSON(url, function(SunsetResponse) {
			console.log(SunsetResponse);
			var response = SunsetResponse.data.weather[0].astronomy[0].sunset;
            document.getElementById("SetTime").innerHTML= "Sun set: "+response;
		});
	};
	
	$(document).ready(main);
}());
